<!--
 * @Descripttion: Sustainable
 * @version: 1.0.0
 * @Author: Kenny
 * @Date: 2024-01-09 09:42:28
 * @LastEditors: ~
 * @LastEditTime: 2025-06-09 15:36:45
-->

# Mitmproxy

```bash
+ mitmproxy 是一款功能强大且灵活的开源中间人代理工具，主要用于拦截、查看、修改和重放 HTTP/HTTPS 流量。它在网络调试、安全测试、API 开发以及协议分析等领域有着广泛的应用。
# 功能1
+ 代理自创数据结构
## 准备
+ cases：加入必须定义需要代理的接口
+ Json转yaml：http://www.esjson.com/jsontoyaml.html
## 操作流程
+ 1. dos 执行：python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyyaml mitmproxy
+ 2. 打开电脑设置代理 127.0.0.1:8999
+ 2.1. http://mitm.it/下载安装：🔏 Get mitmproxy-ca-cert.p12
+ 3. 双击 windows_go.bat
     或者 python "D:\\ITWindows\\Mitmproxy\\case.py"
## 代理
localhost;127._;10._;172.16._;172.17._;172.18._;172.19._;172.20._;172.21._;172.22._;172.23._;172.24._;172.25._;172.26._;172.27._;172.28._;172.29._;172.30._;172.31._;192.168._;127.0.0.1;_.local;137.220.142.162;34.92.76.150;8.134.37.106;8.8.4.4;8.8.8.8

# 功能2
+ 抓包
## 操作流程
+ 启动命令：mitmweb：*:8080作为代理端口
+ 获取ipconfig：IP
+ 手机WiFi配置代理：IP 8080
+ 安装CA证书：mitm.it（代理配置生效，手机会打开下载，选择自己的手机系统）
* 设置->通用->关于本机->证书信任设置，信任新安装的证书即可

# 功能2.1
+ 需要用IDEA打开：配置 run case-capturePacket.py（暂时未打开）
```
