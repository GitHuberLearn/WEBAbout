import os
import json
from mitmproxy import http


def generate_python_code(flow):
    request = flow.request
    url = request.url
    method = request.method
    headers = dict(request.headers)
    query_params = dict(request.query)
    body = request.content.decode('utf-8') if request.content else None

    response_content = flow.response.content.decode('utf-8') if flow.response.content else 'None'
    try:
        response_json = json.loads(response_content)
        code_value = response_json.get('code', 'None')
    except json.JSONDecodeError:
        code_value = 'None (Not a JSON response)'

    code = f"""
编写测试代码
import requests
url = "{url}"
headers = {json.dumps(headers)}
data = "{body}" 
query_params = {json.dumps(query_params)}
response = requests.{method.lower()}(url, headers=headers, params=query_params, data=data)
print(response.text)
发送请求

请求成功
返回值 {response_content!r}
"""
    print(code)
    return code


def write_to_file(data):
    with open("python_code.txt", "a", encoding="utf-8") as file:
        file.write(data + "\n\n")


def response(flow: http.HTTPFlow):
    python_code = generate_python_code(flow)
    write_to_file(python_code)


if __name__ == '__main__':
    os.system(f'mitmdump -p 8888 -s "{__file__}"')