'''
Descripttion: Sustainable
version: 1.0.0
Author: Kenny
Date: 2024-01-09 09:42:28
LastEditors: ~
LastEditTime: 2025-05-28 10:02:01
'''
import os
from mitmproxy import http
import json
import yaml

def read_yaml(files):
    # 读取yaml文件，转为json格式
    with open(files, 'r',encoding='utf-8',errors='ignore') as f:
        result = yaml.load(f.read(), Loader=yaml.FullLoader)
    return result
    
    
root_path = 'D:\\ITWindows\\Mitmproxy\\'
def response(flow:http.HTTPFlow):
    cases = {
        # 必须定义需要代理的接口
        # community_dealer
        'getReservationPage': '',

        # community_bus
        # 首页 慢病管理 血糖分析
        'bloodSugarAnalysisSectorV2': '',
        # 首页 慢病管理 血压分析
        'selectHighBloodV3': '',
        # 首页 慢病管理 血脂分析
        'bloodFatAnalysisV2': '',
        # 首页 未病预估 全部
        'selectNewNotIllStatistics': '',
        # 首页 未病预估 男
        'selectNewNotIllStatistic': 'sex=1',
        # 首页 未病预估 女
        'selectNewNotIllStatisti': 'sex=0',
        # 首页 风险预估 脑梗 全部
        'selectRiskDataUserRiskNum': '%E8%84%91%E6%A2%97',
        # 首页 风险预估 脑出血 全部
        'selectRiskDataUserRiskNu': '%E8%84%91%E5%87%BA%E8%A1%80',
        # 首页 风险预估 心肌梗塞 全部
        'selectRiskDataUserRiskN': '%E5%BF%83%E8%82%8C%E7%BC%BA%E6%B0%A7',
        # 首页 睡眠监测
        'sleepMonitoring': '',
        # 首页 疲劳预警
        'selectFatigueWarningV2': '',
        # 首页 心理预警 女
        'psychologicalStatisticsNew': 'gender=0',
        # 首页 心理预警 男
        'psychologicalStatistics': 'gender=1',
        # 糖代谢异常人群
        'selectMovementAnalysisPhysicalV2': 'cho_metabolic_abnormal',
        # 嘌呤代谢异常
        'selectMovementAnalysisPhysicalV': 'purine_metabolic_abnormal',
        # 脂代谢异常
        'selectMovementAnalysis': 'fat_metabolic_abnormal',
        # 首页 用药评估
        'selectDrugUserListFilter': '',
        # 首页-当日预约-待完成
        'selectLargeAppointmentList': 'appointmentState=0',
        # 首页-当日预约-进行中
        'selectLargeAppointmentLis': 'appointmentState=1',
        # 首页-当日预约-已完成
        'selectLargeAppointmentLi': 'appointmentState=2',
    }

    for api,end in cases.items():
        #端口设置不应该其他网址api
        #if 'dev.seer-health.com' in flow.request.pretty_url:
        if api in flow.request.pretty_url and end in flow.request.pretty_url:
            # 获取原型返回内容
            data = json.loads(flow.response.content)
            print(f'-----接口--{api}----------')
            print(flow.request.pretty_url)
            print(data)
            # 读取做出的返回为0内容
            # respense_data = read_yaml(f'{ root_path }yaml_response\\community_screen\\{ api }.yaml')
            # 读取做出的返回为有数据内容
            respense_data = read_yaml(f'./yaml_response\\community_dealer\\{ api }.yaml')
            # 替换之前的返回
            flow.response.text = json.dumps(respense_data)
        else:
            pass
        #else:
        #  pass



if __name__ == '__main__':
    #os.system('python -m pip install  -i https://pypi.tuna.tsinghua.edu.cn/simple pyyaml mitmproxy json')

    os.system('mitmdump -p 8999 -s case.py')

